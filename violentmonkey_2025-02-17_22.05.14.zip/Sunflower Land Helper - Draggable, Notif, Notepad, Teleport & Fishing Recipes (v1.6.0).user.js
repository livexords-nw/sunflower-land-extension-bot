// ==UserScript==
// @name         Sunflower Land Helper - Draggable, Notif, Notepad, Teleport & Fishing Recipes (v1.6.0)
// @namespace    http://tampermonkey.net/
// @version      1.6.0
// @description  Mod menu Sunflower Land dengan fitur auto (auto farm, auto mine, auto cut tree), notepad, teleport, fishing recipes, dan update info. Terdapat pilihan bahasa (default English, dapat dialihkan ke Indonesia). Popup tidak bisa di‑resize (cukup scroll) dan tombol “Info Update” berada di paling bawah. Footer menampilkan info creator dan versi. Dropdown bahasa sudah bergaya gelap agar teksnya jelas (putih).
// @match        https://sunflower-land.com/play/*
// @grant        GM_addStyle
// ==/UserScript==

(function() {
    'use strict';

    /* === Translation Dictionary === */
    const translations = {
        en: {
            mainTitle: "Sunflower Land",
            farmingAssistant: "Farming Assistant",
            notepad: "Notepad",
            teleport: "Teleport",
            fishingRecipes: "Fishing Recipes",
            updateInfo: "Update Info",
            language: "Language",
            english: "English",
            indonesian: "Indonesia",
            creator: "Creator: LIVEXORDS",
            version: "Version: 1.6.0",
            // Popup headers
            farmingAssistantTitle: "Farming Assistant",
            teleportTitle: "Teleport",
            updateTitle: "Update Info",
            notepadTitle: "Notepad",
            fishingRecipesTitle: "Fishing Recipes",
            // Button texts inside popups
            scan: "Scan",
            autoFarm: "Auto Farm: ",
            autoMine: "Auto Mine: ",
            autoCutTree: "Auto Cut Tree: ",
            teleportToHome: "Teleport to Home",
            teleportBtn: "Teleport",
            save: "Save",
            notepadPlaceholder: "Write your notes here...",
            // Toggle states
            off: "OFF",
            on: "ON",
            // Update content (HTML)
            updateContent: "<p><strong>Version:</strong> 1.6.0</p><p><strong>Changelog:</strong></p><ul><li>Fixed auto features bug.</li><li>Added debug notifications.</li><li>Draggable notifications with maximum 3 visible.</li><li>Teleport and Fishing Recipes features added.</li></ul>"
        },
        id: {
            mainTitle: "Sunflower Land",
            farmingAssistant: "Asisten Bertani",
            notepad: "Notepad",
            teleport: "Teleport",
            fishingRecipes: "Resep Memancing",
            updateInfo: "Info Pembaruan",
            language: "Bahasa",
            english: "Inggris",
            indonesian: "Indonesia",
            creator: "Pembuat: LIVEXORDS",
            version: "Versi: 1.6.0",
            // Popup headers
            farmingAssistantTitle: "Asisten Bertani",
            teleportTitle: "Teleport",
            updateTitle: "Info Pembaruan",
            notepadTitle: "Notepad",
            fishingRecipesTitle: "Resep Memancing",
            // Button texts inside popups
            scan: "Pindai",
            autoFarm: "Auto Farm: ",
            autoMine: "Auto Tambang: ",
            autoCutTree: "Auto Tumbang Pohon: ",
            teleportToHome: "Teleport ke Rumah",
            teleportBtn: "Teleport",
            save: "Simpan",
            notepadPlaceholder: "Tulis catatan Anda disini...",
            off: "Mati",
            on: "Hidup",
            updateContent: "<p><strong>Versi:</strong> 1.6.0</p><p><strong>Changelog:</strong></p><ul><li>Memperbaiki bug fitur auto.</li><li>Menambahkan notifikasi debug.</li><li>Notifikasi dapat digeser dan maksimal 3 ditampilkan.</li><li>Fitur Teleport dan Resep Memancing ditambahkan.</li></ul>"
        }
    };
    let currentLang = "en";

    // Deklarasi variabel popup secara global
    let helperPopup, teleportPopup, updatePopup, notepadPopup, fishingRecipesPopup;

    /* === Load Resources === */
    let linkFont = document.createElement('link');
    linkFont.rel = 'stylesheet';
    linkFont.href = 'https://fonts.googleapis.com/css2?family=Roboto&display=swap';
    document.head.appendChild(linkFont);

    let linkIzi = document.createElement('link');
    linkIzi.rel = 'stylesheet';
    linkIzi.href = 'https://cdnjs.cloudflare.com/ajax/libs/izitoast/1.4.0/css/iziToast.min.css';
    document.head.appendChild(linkIzi);

    let scriptIzi = document.createElement('script');
    scriptIzi.src = 'https://cdnjs.cloudflare.com/ajax/libs/izitoast/1.4.0/js/iziToast.min.js';
    document.head.appendChild(scriptIzi);

    /* === Custom CSS === */
    GM_addStyle(`
        /* Global font */
        * {
            font-family: 'Roboto', sans-serif;
            font-size: 14px;
        }
        /* Main Menu */
        #mainMenu {
            position: fixed;
            top: 10px;
            left: 10px;
            background: #2e2e2e;
            border: 1px solid #444;
            z-index: 9999;
            width: 220px;
        }
        #mainMenuHeader {
            background: #3a3a3a;
            padding: 5px;
            text-align: center;
            border-bottom: 1px solid #444;
            color: #ffffff;
        }
        #languageContainer {
            padding: 5px;
            text-align: center;
        }
        #languageContainer label {
            margin-right: 5px;
            color: #eee;
        }
        /* Style dropdown agar gelap */
        #languageSelect {
            background: #3a3a3a;
            color: #eee;
            border: 1px solid #444;
        }
        /* Supaya item di dropdown juga gelap & putih */
        #languageSelect option {
            background: #3a3a3a;
            color: #eee;
        }
        #mainMenuContent {
            padding: 5px;
        }
        #mainMenu button {
            margin: 2px 0;
            padding: 5px 10px;
            background: #3a3a3a;
            border: 1px solid #444;
            color: #eee;
            cursor: pointer;
            width: 100%;
        }
        #footerInfo {
            text-align: center;
            padding: 5px;
            border-top: 1px solid #444;
            font-size: 12px;
            color: #eee;
        }
        /* Popup styling (semua popup) */
        .popup {
            position: fixed;
            top: 50px;
            left: 50px;
            width: 300px;
            background: #2e2e2e;
            border: 1px solid #444;
            color: #eee;
            z-index: 10000;
            box-shadow: 1px 1px 3px rgba(0,0,0,0.5);
            overflow: auto;
            max-height: 80vh;
        }
        .popupHeader {
            background: #3a3a3a;
            padding: 5px;
            cursor: move;
            user-select: none;
            position: relative;
            border-bottom: 1px solid #444;
        }
        .popupHeader .headerTitle {
            font-weight: bold;
        }
        .popupHeader .minimizeBtn, .popupHeader .closeBtn {
            position: absolute;
            top: 5px;
            cursor: pointer;
            font-weight: bold;
        }
        .popupHeader .minimizeBtn {
            right: 30px;
        }
        .popupHeader .closeBtn {
            right: 10px;
        }
        .popupContent {
            padding: 10px;
        }
        .popupContent button, .popupContent select {
            width: 100%;
            margin-top: 5px;
            padding: 5px;
            border: 1px solid #444;
            background: #3a3a3a;
            color: #eee;
            cursor: pointer;
        }
        #infoSection div {
            margin: 3px 0;
        }
        /* Style khusus untuk Notepad */
        #notepadContent {
            width: 100%;
            height: 150px;
            resize: vertical;
            padding: 5px;
            box-sizing: border-box;
            background: #3a3a3a;
            border: 1px solid #444;
            color: #eee;
        }
    `);

    /* === Utility: Fungsi Draggable === */
    function makeDraggable(el, handle) {
        let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
        handle.onmousedown = dragMouseDown;
        function dragMouseDown(e) {
            e = e || window.event;
            e.preventDefault();
            pos3 = e.clientX;
            pos4 = e.clientY;
            document.onmouseup = closeDragElement;
            document.onmousemove = elementDrag;
        }
        function elementDrag(e) {
            e = e || window.event;
            e.preventDefault();
            pos1 = pos3 - e.clientX;
            pos2 = pos4 - e.clientY;
            pos3 = e.clientX;
            pos4 = e.clientY;
            el.style.top = (el.offsetTop - pos2) + "px";
            el.style.left = (el.offsetLeft - pos1) + "px";
        }
        function closeDragElement() {
            document.onmouseup = null;
            document.onmousemove = null;
        }
    }

    /* === Notifikasi Kustom (Toast) === */
    let activeToasts = [];
    function showToast(type, title, message) {
        if (activeToasts.length >= 3) {
            let oldest = activeToasts.shift();
            oldest.hide({ transitionOut: 'fadeOut' }, function() {
                this.remove();
            });
        }
        let toastOptions = {
            title: title,
            message: message,
            position: 'topRight',
            timeout: 3000,
            onOpened: function(instance, toast) {
                makeDraggable(toast, toast);
            }
        };
        let toast;
        if (type === 'success') {
            toast = iziToast.success(toastOptions);
        } else if (type === 'error') {
            toast = iziToast.error(toastOptions);
        } else {
            toast = iziToast.info(toastOptions);
        }
        activeToasts.push(toast);
    }

    /* === Variabel Auto Features === */
    let autoFarmEnabled = false, autoFarmTimeout;
    let autoMineEnabled = false, autoMineTimeout;
    let autoCutTreeEnabled = false, autoCutTreeTimeout;
    function stopAllAutoFeatures() {
        if (autoFarmEnabled) {
            autoFarmEnabled = false;
            clearTimeout(autoFarmTimeout);
        }
        if (autoMineEnabled) {
            autoMineEnabled = false;
            clearTimeout(autoMineTimeout);
        }
        if (autoCutTreeEnabled) {
            autoCutTreeEnabled = false;
            clearTimeout(autoCutTreeTimeout);
        }
    }

    /* === MAIN MENU === */
    let mainMenu = document.createElement("div");
    mainMenu.id = "mainMenu";
    mainMenu.innerHTML = `
        <div id="mainMenuHeader">${translations[currentLang].mainTitle}</div>
        <div id="languageContainer">
            <label id="languageLabel" for="languageSelect">${translations[currentLang].language}:</label>
            <select id="languageSelect">
                <option value="en">${translations[currentLang].english}</option>
                <option value="id">${translations[currentLang].indonesian}</option>
            </select>
        </div>
        <div id="mainMenuContent">
            <button id="openFarmingAssistant">${translations[currentLang].farmingAssistant}</button>
            <button id="openNotepad">${translations[currentLang].notepad}</button>
            <button id="openTeleport">${translations[currentLang].teleport}</button>
            <button id="openFishingRecipes">${translations[currentLang].fishingRecipes}</button>
            <button id="openUpdate">${translations[currentLang].updateInfo}</button>
        </div>
        <div id="footerInfo">${translations[currentLang].creator} | ${translations[currentLang].version}</div>
    `;
    document.body.appendChild(mainMenu);
    makeDraggable(mainMenu, mainMenu.querySelector("#mainMenuHeader"));

    /* === Update Main Menu Language === */
    function updateMainMenuLanguage() {
        document.getElementById("mainMenuHeader").textContent = translations[currentLang].mainTitle;
        document.getElementById("languageLabel").textContent = translations[currentLang].language + ":";
        document.getElementById("openFarmingAssistant").textContent = translations[currentLang].farmingAssistant;
        document.getElementById("openNotepad").textContent = translations[currentLang].notepad;
        document.getElementById("openTeleport").textContent = translations[currentLang].teleport;
        document.getElementById("openFishingRecipes").textContent = translations[currentLang].fishingRecipes;
        document.getElementById("openUpdate").textContent = translations[currentLang].updateInfo;
        document.getElementById("footerInfo").innerHTML = translations[currentLang].creator + " | " + translations[currentLang].version;
    }
    document.getElementById("languageSelect").addEventListener("change", function() {
        currentLang = this.value;
        updateMainMenuLanguage();
        updateAllPopupsLanguage();
    });

    /* === Update Popup Language Jika Terbuka === */
    function updateAllPopupsLanguage() {
        if (helperPopup) {
            let header = helperPopup.querySelector(".popupHeader .headerTitle");
            if(header) header.textContent = translations[currentLang].farmingAssistantTitle;
            helperPopup.querySelector("#scanButton").textContent = translations[currentLang].scan;
            helperPopup.querySelector("#autoFarmButton").textContent = translations[currentLang].autoFarm + (autoFarmEnabled ? translations[currentLang].on : translations[currentLang].off);
            helperPopup.querySelector("#autoMineButton").textContent = translations[currentLang].autoMine + (autoMineEnabled ? translations[currentLang].on : translations[currentLang].off);
            helperPopup.querySelector("#autoCutTreeButton").textContent = translations[currentLang].autoCutTree + (autoCutTreeEnabled ? translations[currentLang].on : translations[currentLang].off);
        }
        if (teleportPopup) {
            let header = teleportPopup.querySelector(".popupHeader .headerTitle");
            if(header) header.textContent = translations[currentLang].teleportTitle;
            teleportPopup.querySelector("#teleportToHome").textContent = translations[currentLang].teleportToHome;
            teleportPopup.querySelector("#teleportBtn").textContent = translations[currentLang].teleportBtn;
        }
        if (updatePopup) {
            let header = updatePopup.querySelector(".popupHeader .headerTitle");
            if(header) header.textContent = translations[currentLang].updateTitle;
            updatePopup.querySelector(".popupContent").innerHTML = translations[currentLang].updateContent;
        }
        if (notepadPopup) {
            let header = notepadPopup.querySelector(".popupHeader .headerTitle");
            if(header) header.textContent = translations[currentLang].notepadTitle;
            notepadPopup.querySelector("#saveNotepad").textContent = translations[currentLang].save;
            notepadPopup.querySelector("#notepadContent").placeholder = translations[currentLang].notepadPlaceholder;
        }
        if (fishingRecipesPopup) {
            let header = fishingRecipesPopup.querySelector(".popupHeader .headerTitle");
            if(header) header.textContent = translations[currentLang].fishingRecipesTitle;
        }
    }

    /* === POPUP FARMING ASSISTANT (Helper) === */
    function openFarmingAssistantPopup() {
        if (!helperPopup) {
            helperPopup = document.createElement("div");
            helperPopup.id = "helperPopup";
            helperPopup.className = "popup";
            helperPopup.innerHTML = `
                <div class="popupHeader">
                    <span class="headerTitle">${translations[currentLang].farmingAssistantTitle}</span>
                    <span class="minimizeBtn">–</span>
                    <span class="closeBtn">x</span>
                </div>
                <div class="popupContent">
                    <button id="scanButton">${translations[currentLang].scan}</button>
                    <div id="infoSection">
                        <div>Total Plants: <span id="plantCount">0</span></div>
                        <div>Trees: <span id="treeCount">0</span></div>
                        <div>Empty Soil: <span id="emptySoilCount">0</span></div>
                        <div>Stone: <span id="stoneCount">0</span></div>
                        <div>Iron Ore: <span id="ironCount">0</span></div>
                        <div>Gold Ore: <span id="goldCount">0</span></div>
                    </div>
                    <button id="autoFarmButton">${translations[currentLang].autoFarm}${translations[currentLang].off}</button>
                    <div id="autoMineOptions">
                        <label>Mine Type:</label>
                        <select id="mineTypeSelect">
                            <option value="stone" selected>Stone</option>
                            <option value="iron">Iron Ore</option>
                            <option value="gold">Gold Ore</option>
                        </select>
                    </div>
                    <button id="autoMineButton">${translations[currentLang].autoMine}${translations[currentLang].off}</button>
                    <button id="autoCutTreeButton">${translations[currentLang].autoCutTree}${translations[currentLang].off}</button>
                </div>
            `;
            document.body.appendChild(helperPopup);
            makeDraggable(helperPopup, helperPopup.querySelector(".popupHeader"));
            let minimizeBtn = helperPopup.querySelector(".minimizeBtn");
            let closeBtn = helperPopup.querySelector(".closeBtn");
            let content = helperPopup.querySelector(".popupContent");
            minimizeBtn.addEventListener("click", () => {
                if (content.style.display === "none") {
                    content.style.display = "block";
                    minimizeBtn.textContent = "–";
                } else {
                    content.style.display = "none";
                    minimizeBtn.textContent = "+";
                }
            });
            closeBtn.addEventListener("click", () => {
                stopAllAutoFeatures();
                helperPopup.remove();
                helperPopup = null;
                showToast('info', translations[currentLang].farmingAssistantTitle + ' Closed', 'All auto features stopped.');
            });
            helperPopup.querySelector("#scanButton").addEventListener("click", scanElements);
            helperPopup.querySelector("#autoFarmButton").addEventListener("click", toggleAutoFarm);
            helperPopup.querySelector("#autoMineButton").addEventListener("click", toggleAutoMine);
            helperPopup.querySelector("#autoCutTreeButton").addEventListener("click", toggleAutoCutTree);
        } else {
            helperPopup.style.display = "block";
        }
    }

    /* === POPUP TELEPORT === */
    function openTeleportPopup() {
        if (!teleportPopup) {
            teleportPopup = document.createElement("div");
            teleportPopup.id = "teleportPopup";
            teleportPopup.className = "popup";
            teleportPopup.innerHTML = `
                <div class="popupHeader">
                    <span class="headerTitle">${translations[currentLang].teleportTitle}</span>
                    <span class="minimizeBtn">–</span>
                    <span class="closeBtn">x</span>
                </div>
                <div class="popupContent">
                    <button id="teleportToHome">${translations[currentLang].teleportToHome}</button>
                    <select id="teleportDropdown">
                        <option value="world/plaza">Plaza</option>
                        <option value="world/beach">Beach</option>
                        <option value="world/forest">Forest</option>
                        <option value="world/retreat">Retreat</option>
                    </select>
                    <button id="teleportBtn">${translations[currentLang].teleportBtn}</button>
                </div>
            `;
            document.body.appendChild(teleportPopup);
            makeDraggable(teleportPopup, teleportPopup.querySelector(".popupHeader"));
            let minimizeBtn = teleportPopup.querySelector(".minimizeBtn");
            let closeBtn = teleportPopup.querySelector(".closeBtn");
            let content = teleportPopup.querySelector(".popupContent");
            minimizeBtn.addEventListener("click", () => {
                if (content.style.display === "none") {
                    content.style.display = "block";
                    minimizeBtn.textContent = "–";
                } else {
                    content.style.display = "none";
                    minimizeBtn.textContent = "+";
                }
            });
            closeBtn.addEventListener("click", () => {
                teleportPopup.remove();
                teleportPopup = null;
            });
            teleportPopup.querySelector("#teleportToHome").addEventListener("click", () => {
                window.location.href = "https://sunflower-land.com/play/#/";
            });
            teleportPopup.querySelector("#teleportBtn").addEventListener("click", () => {
                const dropdown = teleportPopup.querySelector("#teleportDropdown");
                const selected = dropdown.value;
                window.location.href = "https://sunflower-land.com/play/#/" + selected;
            });
        } else {
            teleportPopup.style.display = "block";
        }
    }

    /* === POPUP UPDATE INFO === */
    function openUpdatePopup() {
        if (!updatePopup) {
            updatePopup = document.createElement("div");
            updatePopup.id = "updatePopup";
            updatePopup.className = "popup";
            updatePopup.innerHTML = `
                <div class="popupHeader">
                    <span class="headerTitle">${translations[currentLang].updateTitle}</span>
                    <span class="minimizeBtn">–</span>
                    <span class="closeBtn">x</span>
                </div>
                <div class="popupContent">
                    ${translations[currentLang].updateContent}
                </div>
            `;
            document.body.appendChild(updatePopup);
            makeDraggable(updatePopup, updatePopup.querySelector(".popupHeader"));
            let minimizeBtn = updatePopup.querySelector(".minimizeBtn");
            let closeBtn = updatePopup.querySelector(".closeBtn");
            let content = updatePopup.querySelector(".popupContent");
            minimizeBtn.addEventListener("click", () => {
                if (content.style.display === "none") {
                    content.style.display = "block";
                    minimizeBtn.textContent = "–";
                } else {
                    content.style.display = "none";
                    minimizeBtn.textContent = "+";
                }
            });
            closeBtn.addEventListener("click", () => {
                updatePopup.remove();
                updatePopup = null;
            });
        } else {
            updatePopup.style.display = "block";
        }
    }

    /* === POPUP NOTEPAD === */
    function openNotepadPopup() {
        if (!notepadPopup) {
            notepadPopup = document.createElement("div");
            notepadPopup.id = "notepadPopup";
            notepadPopup.className = "popup";
            notepadPopup.innerHTML = `
                <div class="popupHeader">
                    <span class="headerTitle">${translations[currentLang].notepadTitle}</span>
                    <span class="minimizeBtn">–</span>
                    <span class="closeBtn">x</span>
                </div>
                <div class="popupContent">
                    <textarea id="notepadContent" placeholder="${translations[currentLang].notepadPlaceholder}"></textarea>
                    <button id="saveNotepad">${translations[currentLang].save}</button>
                </div>
            `;
            document.body.appendChild(notepadPopup);
            makeDraggable(notepadPopup, notepadPopup.querySelector(".popupHeader"));
            let minimizeBtn = notepadPopup.querySelector(".minimizeBtn");
            let closeBtn = notepadPopup.querySelector(".closeBtn");
            let content = notepadPopup.querySelector(".popupContent");
            minimizeBtn.addEventListener("click", () => {
                if (content.style.display === "none") {
                    content.style.display = "block";
                    minimizeBtn.textContent = "–";
                } else {
                    content.style.display = "none";
                    minimizeBtn.textContent = "+";
                }
            });
            closeBtn.addEventListener("click", () => {
                notepadPopup.remove();
                notepadPopup = null;
            });
            let textarea = notepadPopup.querySelector("#notepadContent");
            textarea.value = localStorage.getItem("sunflowerNotepad") || "";
            notepadPopup.querySelector("#saveNotepad").addEventListener("click", () => {
                localStorage.setItem("sunflowerNotepad", textarea.value);
                showToast('success', translations[currentLang].save, 'Notepad saved.');
            });
        } else {
            notepadPopup.style.display = "block";
        }
    }

    /* === POPUP FISHING RECIPES === */
    function openFishingRecipesPopup() {
        if (!fishingRecipesPopup) {
            fishingRecipesPopup = document.createElement("div");
            fishingRecipesPopup.id = "fishingRecipesPopup";
            fishingRecipesPopup.className = "popup";
            fishingRecipesPopup.innerHTML = `
                <div class="popupHeader">
                    <span class="headerTitle">${translations[currentLang].fishingRecipesTitle}</span>
                    <span class="minimizeBtn">–</span>
                    <span class="closeBtn">x</span>
                </div>
                <div class="popupContent">
                    <!-- Menampilkan resep memancing dari website sfl.world -->
                    <iframe src="https://sfl.world/util/fishing" style="width:100%; height:500px; border:none;"></iframe>
                </div>
            `;
            document.body.appendChild(fishingRecipesPopup);
            makeDraggable(fishingRecipesPopup, fishingRecipesPopup.querySelector(".popupHeader"));
            let minimizeBtn = fishingRecipesPopup.querySelector(".minimizeBtn");
            let closeBtn = fishingRecipesPopup.querySelector(".closeBtn");
            let content = fishingRecipesPopup.querySelector(".popupContent");
            minimizeBtn.addEventListener("click", () => {
                if (content.style.display === "none") {
                    content.style.display = "block";
                    minimizeBtn.textContent = "–";
                } else {
                    content.style.display = "none";
                    minimizeBtn.textContent = "+";
                }
            });
            closeBtn.addEventListener("click", () => {
                fishingRecipesPopup.remove();
                fishingRecipesPopup = null;
            });
        } else {
            fishingRecipesPopup.style.display = "block";
        }
    }

    /* === Event Listener Main Menu === */
    document.getElementById("openFarmingAssistant").addEventListener("click", openFarmingAssistantPopup);
    document.getElementById("openNotepad").addEventListener("click", openNotepadPopup);
    document.getElementById("openTeleport").addEventListener("click", openTeleportPopup);
    document.getElementById("openFishingRecipes").addEventListener("click", openFishingRecipesPopup);
    document.getElementById("openUpdate").addEventListener("click", openUpdatePopup);

    /* === Fungsi-Fungsi Helper === */
    const plantNames = [
        "sunflower", "rhubarb", "carrot", "cabbage", "soybean", "corn", "wheat",
        "kale", "barley", "tomato", "blueberry", "orange", "sunpetal", "bloom",
        "lavender", "lily", "grape", "rice", "olive", "potato", "pumpkin", "zuchinni", "brocolli", "beetroot", "pepper",
        "cauliflower", "parsnip", "eggplant", "onion"
    ];
    function scanElements() {
        let mainContainer = document.evaluate(
            '/html/body/div[1]/div/div/div[2]/div/div[1]/div',
            document,
            null,
            XPathResult.FIRST_ORDERED_NODE_TYPE,
            null
        ).singleNodeValue;
        if (!mainContainer) {
            console.warn("XPath not found!");
            return;
        }
        let totalPlantCount = 0;
        plantNames.forEach(plant => {
            let imgs = mainContainer.querySelectorAll('div img[src*="game-assets/crops/' + plant + '/plant.png"]');
            totalPlantCount += imgs.length;
        });
        let treeImgs = mainContainer.querySelectorAll('div img[src*="game-assets/resources/tree/Basic/spring_basic_tree.webp"]');
        let emptySoilImgs = mainContainer.querySelectorAll('div img[src*="game-assets/crops/soil2.png"]');
        let stoneImgs = mainContainer.querySelectorAll('div img[src*="game-assets/resources/stone_small.png"]');
        let ironImgs = mainContainer.querySelectorAll('div img[src*="game-assets/resources/iron_small.png"]');
        let goldImgs = mainContainer.querySelectorAll('div img[src*="game-assets/resources/gold_small.png"]');
        if(document.getElementById("plantCount")) document.getElementById("plantCount").textContent = totalPlantCount;
        if(document.getElementById("treeCount")) document.getElementById("treeCount").textContent = treeImgs.length;
        if(document.getElementById("emptySoilCount")) document.getElementById("emptySoilCount").textContent = emptySoilImgs.length;
        if(document.getElementById("stoneCount")) document.getElementById("stoneCount").textContent = stoneImgs.length;
        if(document.getElementById("ironCount")) document.getElementById("ironCount").textContent = ironImgs.length;
        if(document.getElementById("goldCount")) document.getElementById("goldCount").textContent = goldImgs.length;
        showToast('info', translations[currentLang].scan + " " + translations[currentLang].off,
            "Plants: " + totalPlantCount +
            ", Trees: " + treeImgs.length +
            ", Soil: " + emptySoilImgs.length +
            ", Stone: " + stoneImgs.length +
            ", Iron: " + ironImgs.length +
            ", Gold: " + goldImgs.length);
    }
    function harvestPlants() {
        let mainContainer = document.evaluate(
            '/html/body/div[1]/div/div/div[2]/div/div[1]/div',
            document,
            null,
            XPathResult.FIRST_ORDERED_NODE_TYPE,
            null
        ).singleNodeValue;
        if (!mainContainer) {
            console.warn("XPath not found!");
            return;
        }
        let allPlantImgs = [];
        plantNames.forEach(plant => {
            let imgs = Array.from(mainContainer.querySelectorAll('div img[src*="game-assets/crops/' + plant + '/plant.png"]'));
            allPlantImgs = allPlantImgs.concat(imgs);
        });
        let delay = getDelay();
        let i = 0;
        function processNext() {
            if (i >= allPlantImgs.length) return;
            let img = allPlantImgs[i];
            let clickableDiv = img.closest('div');
            if (clickableDiv) {
                clickableDiv.click();
                setTimeout(() => {
                    img.click();
                    i++;
                    setTimeout(processNext, delay);
                }, delay);
            } else {
                i++;
                processNext();
            }
        }
        processNext();
    }
    function clickEmptySoil() {
        let mainContainer = document.evaluate(
            '/html/body/div[1]/div/div/div[2]/div/div[1]/div',
            document,
            null,
            XPathResult.FIRST_ORDERED_NODE_TYPE,
            null
        ).singleNodeValue;
        if (!mainContainer) {
            console.warn("XPath not found!");
            return;
        }
        let emptySoilImgs = Array.from(mainContainer.querySelectorAll('div img[src*="game-assets/crops/soil2.png"]'));
        let delay = getDelay();
        let i = 0;
        function processNext() {
            if (i >= emptySoilImgs.length) return;
            let img = emptySoilImgs[i];
            let clickableDiv = img.closest('div');
            if (clickableDiv) {
                clickableDiv.click();
                setTimeout(() => {
                    img.click();
                    i++;
                    setTimeout(processNext, delay);
                }, delay);
            } else {
                i++;
                processNext();
            }
        }
        processNext();
    }
    function getDelay() {
        return 300;
    }
    function autoCycle() {
        if (!autoFarmEnabled) return;
        harvestPlants();
        setTimeout(() => {
            clickEmptySoil();
            autoFarmTimeout = setTimeout(autoCycle, getDelay());
        }, getDelay() * 2);
    }
    function toggleAutoFarm() {
        autoFarmEnabled = !autoFarmEnabled;
        const btn = document.getElementById("autoFarmButton");
        if (autoFarmEnabled) {
            btn.textContent = translations[currentLang].autoFarm + translations[currentLang].on;
            showToast('success', translations[currentLang].autoFarm + translations[currentLang].on, "Auto Farm activated.");
            autoCycle();
        } else {
            btn.textContent = translations[currentLang].autoFarm + translations[currentLang].off;
            showToast('error', translations[currentLang].autoFarm + translations[currentLang].off, "Auto Farm deactivated.");
            clearTimeout(autoFarmTimeout);
        }
    }
    function autoMine() {
        let mineType = document.getElementById("mineTypeSelect").value;
        let mainContainer = document.evaluate(
            '/html/body/div[1]/div/div/div[2]/div/div[1]/div',
            document,
            null,
            XPathResult.FIRST_ORDERED_NODE_TYPE,
            null
        ).singleNodeValue;
        if (!mainContainer) {
            console.warn("Main container not found!");
            return;
        }
        let resourceImgs = mainContainer.querySelectorAll(`div img[src*="game-assets/resources/${mineType}_small.png"]`);
        let resourceChains = [];
        resourceImgs.forEach(img => {
            let clickableDiv = img.closest('div');
            if (!clickableDiv) return;
            let chain = [];
            let current = clickableDiv;
            while (current && mainContainer.contains(current)) {
                chain.push(current);
                current = current.parentElement;
            }
            resourceChains.push(chain);
        });
        function processChain(index) {
            if (index >= resourceChains.length) return;
            let chain = resourceChains[index];
            function clickChain(rep) {
                if (rep >= 3) {
                    setTimeout(() => processChain(index + 1), 1000);
                    return;
                }
                chain.forEach(el => el.click());
                setTimeout(() => clickChain(rep + 1), 500);
            }
            clickChain(0);
        }
        processChain(0);
    }
    function autoMineCycle() {
        if (!autoMineEnabled) return;
        autoMine();
        autoMineTimeout = setTimeout(autoMineCycle, getDelay());
    }
    function toggleAutoMine() {
        autoMineEnabled = !autoMineEnabled;
        const btn = document.getElementById("autoMineButton");
        if (autoMineEnabled) {
            btn.textContent = translations[currentLang].autoMine + translations[currentLang].on;
            showToast('success', translations[currentLang].autoMine + translations[currentLang].on, "Auto Mine activated.");
            autoMineCycle();
        } else {
            btn.textContent = translations[currentLang].autoMine + translations[currentLang].off;
            showToast('error', translations[currentLang].autoMine + translations[currentLang].off, "Auto Mine deactivated.");
            clearTimeout(autoMineTimeout);
        }
    }
    function autoCutTree() {
        let mainContainer = document.evaluate(
            '/html/body/div[1]/div/div/div[2]/div/div[1]/div',
            document,
            null,
            XPathResult.FIRST_ORDERED_NODE_TYPE,
            null
        ).singleNodeValue;
        if (!mainContainer) {
            console.warn("XPath not found!");
            return;
        }
        let treeImgs = mainContainer.querySelectorAll('div img[src*="game-assets/resources/tree/"]');
        let treeChains = [];
        treeImgs.forEach(img => {
            let clickableDiv = img.closest('div');
            if (!clickableDiv) return;
            let chain = [];
            let current = clickableDiv;
            while (current && mainContainer.contains(current)) {
                chain.push(current);
                current = current.parentElement;
            }
            treeChains.push(chain);
        });
        function processChain(index) {
            if (index >= treeChains.length) return;
            let chain = treeChains[index];
            function clickChain(rep) {
                if (rep >= 3) {
                    setTimeout(() => processChain(index + 1), 1000);
                    return;
                }
                chain.forEach(el => el.click());
                setTimeout(() => clickChain(rep + 1), 1000);
            }
            clickChain(0);
        }
        processChain(0);
    }
    function autoCutTreeCycle() {
        if (!autoCutTreeEnabled) return;
        autoCutTree();
        autoCutTreeTimeout = setTimeout(autoCutTreeCycle, getDelay());
    }
    function toggleAutoCutTree() {
        autoCutTreeEnabled = !autoCutTreeEnabled;
        const btn = document.getElementById("autoCutTreeButton");
        if (autoCutTreeEnabled) {
            btn.textContent = translations[currentLang].autoCutTree + translations[currentLang].on;
            showToast('success', translations[currentLang].autoCutTree + translations[currentLang].on, "Auto Cut Tree activated.");
            autoCutTreeCycle();
        } else {
            btn.textContent = translations[currentLang].autoCutTree + translations[currentLang].off;
            showToast('error', translations[currentLang].autoCutTree + translations[currentLang].off, "Auto Cut Tree deactivated.");
            clearTimeout(autoCutTreeTimeout);
        }
    }
})();
